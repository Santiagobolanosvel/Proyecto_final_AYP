import os
import tkinter as tk
from tkinter import ttk, messagebox, font as tkfont
from datetime import datetime

# =====================================================================
# RUTAS Y ARCHIVOS DE PERSISTENCIA (.txt)
# =====================================================================
BASE_DIR = os.path.dirname(os.path.abspath(__file__))


def ruta(nombre):
    return os.path.join(BASE_DIR, nombre)


archivo_usuarios = ruta("usuarios.txt")
archivo_bodega = ruta("bodega.txt")
archivo_herramientas = ruta("herramientas.txt")
archivo_proyectos = ruta("proyectos.txt")
archivo_reportes = ruta("reportes_herramientas.txt")
archivo_registros = ruta("registros_proyecto.txt")   # actividades y consumos por proyecto

# ---------------------------------------------------------------------
# Valores de referencia para calcular el costo REAL de un proyecto.
# Ajústalos a los precios reales de la planta (están en pesos).
# ---------------------------------------------------------------------
TARIFA_HORA = 18000          # costo de una hora de trabajo
PRECIOS_CONSUMIBLES = {      # precio por unidad de cada consumible de la bodega
    "Electrodos": 1500,
    "Disco de corte": 9000,
    "Pintura (galones)": 85000,
    "Cable eléctrico (m)": 3500,
    "Lija": 1800,
    "Disco de pulir": 12000,
    "Brocas": 7000,
}

CARGOS = [
    "ayudante",
    "soldador",
    "almacenista",
    "armador",
    "pintor",
    "electricista",
    "jefe de planta",
    "ingeniero de proyectos",
    "gerente"
]

usuarios = {}
proyectos = {}
inventario_bodega = {}
inventario_herramientas = {}
reportes_herramientas = []


# =====================================================================
# GESTIÓN Y CARGA DE ARCHIVOS (PERSISTENCIA HISTÓRICA)
# =====================================================================
def inicializar_archivos():
    if not os.path.exists(archivo_usuarios):
        with open(archivo_usuarios, "w", encoding="utf-8") as f:
            f.write("admin|1234|jefe de planta\n")
            f.write("gerente1|1234|gerente\n")
            f.write("ing1|1234|ingeniero de proyectos\n")

    if not os.path.exists(archivo_bodega):
        with open(archivo_bodega, "w", encoding="utf-8") as f:
            f.write("Electrodos|500\n")
            f.write("Disco de corte|150\n")
            f.write("Pintura (galones)|80\n")
            f.write("Cable eléctrico (m)|1000\n")
            f.write("Lija|200\n")
            f.write("Disco de pulir|150\n")
            f.write("Brocas|100\n")

    if not os.path.exists(archivo_herramientas):
        with open(archivo_herramientas, "w", encoding="utf-8") as f:
            f.write("soldador|5\n")
            f.write("pulidora|8\n")
            f.write("compresor de pintura|3\n")

    if not os.path.exists(archivo_proyectos):
        open(archivo_proyectos, "w", encoding="utf-8").close()

    if not os.path.exists(archivo_reportes):
        open(archivo_reportes, "w", encoding="utf-8").close()

    if not os.path.exists(archivo_registros):
        open(archivo_registros, "w", encoding="utf-8").close()

    cargar_datos_desde_archivos()


def cargar_datos_desde_archivos():
    usuarios.clear()
    inventario_bodega.clear()
    inventario_herramientas.clear()
    proyectos.clear()
    reportes_herramientas.clear()

    with open(archivo_usuarios, "r", encoding="utf-8") as f:
        for linea in f:
            datos = linea.strip().split("|")
            if len(datos) >= 3:
                usuarios[datos[0]] = {"clave": datos[1], "cargo": datos[2]}

    with open(archivo_bodega, "r", encoding="utf-8") as f:
        for linea in f:
            datos = linea.strip().split("|")
            if len(datos) >= 2:
                inventario_bodega[datos[0]] = int(datos[1])

    with open(archivo_herramientas, "r", encoding="utf-8") as f:
        for linea in f:
            datos = linea.strip().split("|")
            if len(datos) >= 2:
                inventario_herramientas[datos[0]] = int(datos[1])

    with open(archivo_proyectos, "r", encoding="utf-8") as f:
        for linea in f:
            datos = linea.strip().split("|")
            if len(datos) >= 3:
                nom_p, costo_esp, tiempo_tot = datos[0], float(datos[1]), float(datos[2])
                # el 4.º dato (horas estimadas) es opcional: así sigue funcionando
                # con los proyectos.txt viejos de 3 columnas
                tiempo_est = float(datos[3]) if len(datos) >= 4 and datos[3] else 0.0
                proyectos[nom_p] = {
                    "costo_esperado": costo_esp,
                    "actividades": [],
                    "tiempo_total": tiempo_tot,
                    "tiempo_estimado": tiempo_est,
                    "consumibles": {},
                    "herramientas": []
                }

    # Historial de actividades (A) y consumos sueltos (C) de cada proyecto
    with open(archivo_registros, "r", encoding="utf-8") as f:
        for linea in f:
            datos = linea.rstrip("\n").split("|")
            if len(datos) < 2 or datos[1] not in proyectos:
                continue
            proy = proyectos[datos[1]]
            try:
                if datos[0] == "A" and len(datos) >= 7:
                    horas, item, cant = float(datos[3]), datos[4], int(datos[5])
                    proy["actividades"].append({
                        "descripcion": datos[2],
                        "horas": horas,
                        "consumible": item,
                        "cantidad_consumible": cant,
                        "fecha": datos[6]
                    })
                    if item:
                        proy["consumibles"][item] = proy["consumibles"].get(item, 0) + cant
                elif datos[0] == "C" and len(datos) >= 4:
                    item, cant = datos[2], int(datos[3])
                    proy["consumibles"][item] = proy["consumibles"].get(item, 0) + cant
            except ValueError:
                continue   # línea dañada: se ignora en vez de tumbar el programa


def guardar_bodega():
    with open(archivo_bodega, "w", encoding="utf-8") as f:
        for item, cant in inventario_bodega.items():
            f.write(f"{item}|{cant}\n")


def guardar_herramientas():
    with open(archivo_herramientas, "w", encoding="utf-8") as f:
        for h, cant in inventario_herramientas.items():
            f.write(f"{h}|{cant}\n")


def guardar_proyectos():
    with open(archivo_proyectos, "w", encoding="utf-8") as f:
        for nom_p, datos in proyectos.items():
            f.write(f"{nom_p}|{datos['costo_esperado']}|{datos['tiempo_total']}|"
                    f"{datos.get('tiempo_estimado', 0.0)}\n")


def guardar_registro(linea):
    with open(archivo_registros, "a", encoding="utf-8") as f:
        f.write(linea + "\n")


def calcular_costo_real(datos):
    """Costo real = horas x tarifa + consumibles x precio. Devuelve (total, desglose)."""
    desglose = {"Mano de obra": datos["tiempo_total"] * TARIFA_HORA}
    for item, cant in datos["consumibles"].items():
        desglose[item] = cant * PRECIOS_CONSUMIBLES.get(item, 0)
    return sum(desglose.values()), desglose


# =====================================================================
# LÓGICA DE NEGOCIO (misma del original; devuelve (ok, mensaje))
# =====================================================================
def _texto_valido(texto):
    return "|" not in texto


def leer_entero_positivo(texto):
    try:
        valor = int(str(texto).strip())
    except ValueError:
        return None
    return valor if valor > 0 else None


def leer_decimal(texto):
    try:
        return float(str(texto).strip().replace(",", "."))
    except ValueError:
        return None


def registrar_usuario(nombre, clave, cargo):
    nombre = nombre.strip()
    clave = clave.strip()
    if not nombre or not clave:
        return False, "Debe ingresar el nombre de usuario y la contraseña."
    if not (_texto_valido(nombre) and _texto_valido(clave)):
        return False, "El carácter '|' no está permitido."
    if nombre in usuarios:
        return False, "El nombre de usuario ya se encuentra registrado."
    if cargo not in CARGOS:
        return False, "Seleccione un cargo válido."

    usuarios[nombre] = {"clave": clave, "cargo": cargo}
    with open(archivo_usuarios, "a", encoding="utf-8") as f:
        f.write(f"{nombre}|{clave}|{cargo}\n")
    return True, f"Usuario '{nombre}' con cargo '{cargo}' registrado con éxito."


def iniciar_sesion(nombre, clave):
    nombre = nombre.strip()
    clave = clave.strip()
    if nombre in usuarios and usuarios[nombre]["clave"] == clave:
        datos_usr = usuarios[nombre].copy()
        datos_usr["nombre"] = nombre
        return datos_usr
    return None


def crear_proyecto(nombre):
    nombre = nombre.strip()
    if not nombre:
        return False, "Debe ingresar el nombre del proyecto."
    if not _texto_valido(nombre):
        return False, "El carácter '|' no está permitido."
    if nombre in proyectos:
        return False, "El proyecto ya existe."
    proyectos[nombre] = {
        "costo_esperado": 0.0,
        "actividades": [],
        "tiempo_total": 0.0,
        "tiempo_estimado": 0.0,
        "consumibles": {},
        "herramientas": []
    }
    guardar_proyectos()
    return True, f"Proyecto '{nombre}' creado correctamente."


def registrar_actividad(nombre_p, desc, horas_txt, item_consumible, cant_txt):
    if nombre_p not in proyectos:
        return False, "Seleccione un proyecto existente."
    desc = desc.strip()
    if not desc:
        return False, "Escriba la descripción de la actividad."
    if not _texto_valido(desc):
        return False, "El carácter '|' no está permitido."
    horas = leer_decimal(horas_txt)
    if horas is None or horas < 0:
        return False, "Ingrese una cantidad de horas válida."

    cant_consumible = 0
    if item_consumible:
        if item_consumible not in inventario_bodega:
            return False, "El consumible no existe en la bodega."
        cant_consumible = leer_entero_positivo(cant_txt)
        if cant_consumible is None:
            return False, "Cantidad de consumible no válida."
        if cant_consumible > inventario_bodega[item_consumible]:
            return False, "Stock insuficiente en la bodega."

        inventario_bodega[item_consumible] -= cant_consumible
        guardar_bodega()
        proyectos[nombre_p]["consumibles"][item_consumible] = (
            proyectos[nombre_p]["consumibles"].get(item_consumible, 0) + cant_consumible
        )

    fecha = datetime.now().strftime("%Y-%m-%d %H:%M")
    proyectos[nombre_p]["actividades"].append({
        "descripcion": desc,
        "horas": horas,
        "consumible": item_consumible,
        "cantidad_consumible": cant_consumible,
        "fecha": fecha
    })
    proyectos[nombre_p]["tiempo_total"] += horas
    guardar_proyectos()
    guardar_registro(f"A|{nombre_p}|{desc}|{horas}|{item_consumible}|{cant_consumible}|{fecha}")
    return True, "Actividad registrada correctamente."


def asignar_costo_esperado(nombre_p, costo_txt):
    if nombre_p not in proyectos:
        return False, "Seleccione un proyecto existente."
    costo = leer_decimal(costo_txt)
    if costo is None:
        return False, "Valor numérico inválido."
    proyectos[nombre_p]["costo_esperado"] = costo
    guardar_proyectos()
    return True, f"Costo esperado asignado al proyecto '{nombre_p}': ${costo:,.2f}"


def asignar_horas_estimadas(nombre_p, horas_txt):
    if nombre_p not in proyectos:
        return False, "Seleccione un proyecto existente."
    horas = leer_decimal(horas_txt)
    if horas is None or horas < 0:
        return False, "Ingrese una cantidad de horas válida."
    proyectos[nombre_p]["tiempo_estimado"] = horas
    guardar_proyectos()
    return True, f"Horas estimadas del proyecto '{nombre_p}': {horas:g} h."


def registrar_herramienta(nombre_p, usuario, herramienta, cantidad=1, limitada=False):
    if not herramienta:
        return False, "Debe indicar el nombre de la herramienta."
    if limitada:
        disponibles = inventario_herramientas.get(herramienta, 0)
        if disponibles == 0:
            return False, "No hay unidades disponibles de esta herramienta."
        if cantidad is None:
            return False, "Cantidad no válida."
        if cantidad > disponibles:
            return False, "No hay suficientes unidades disponibles."
        inventario_herramientas[herramienta] -= cantidad
        guardar_herramientas()

    proyectos[nombre_p].setdefault("herramientas", []).append({
        "usuario": usuario,
        "herramienta": herramienta,
        "cantidad": cantidad
    })
    return True, f"Herramienta '{herramienta}' registrada en el proyecto '{nombre_p}'."


def registrar_consumible(nombre_p, usuario, item, cantidad, detalle=""):
    if item not in inventario_bodega:
        return False, "El consumible no existe en la bodega."
    if cantidad is None:
        return False, "Cantidad no válida."
    if cantidad > inventario_bodega[item]:
        return False, "Stock insuficiente en la bodega."
    if not _texto_valido(detalle):
        return False, "El carácter '|' no está permitido."

    inventario_bodega[item] -= cantidad
    guardar_bodega()
    guardar_registro(f"C|{nombre_p}|{item}|{cantidad}|"
                     f"{datetime.now().strftime('%Y-%m-%d %H:%M')}|{detalle}")

    consumos = proyectos[nombre_p]["consumibles"]
    consumos[item] = consumos.get(item, 0) + cantidad
    proyectos[nombre_p].setdefault("detalle_consumibles", []).append({
        "usuario": usuario,
        "consumible": item,
        "cantidad": cantidad,
        "detalle": detalle
    })
    texto_detalle = f" ({detalle})" if detalle else ""
    return True, f"{cantidad} unidad(es) de '{item}'{texto_detalle} registradas en '{nombre_p}'."


def reportar_herramienta_mal_estado(nombre_p, usuario, herramienta, falla):
    herramienta = herramienta.strip()
    if not herramienta:
        return False, "Debe indicar la herramienta."
    if not _texto_valido(herramienta) or not _texto_valido(falla):
        return False, "El carácter '|' no está permitido."
    fecha_hora = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    reportes_herramientas.append({
        "proyecto": nombre_p,
        "usuario": usuario,
        "herramienta": herramienta,
        "falla": falla,
        "fecha": fecha_hora
    })
    with open(archivo_reportes, "a", encoding="utf-8") as f:
        f.write(f"{nombre_p}|{usuario}|{herramienta}|{falla}|{fecha_hora}\n")
    return True, f"Reporte guardado: '{herramienta}' - {falla}."


# =====================================================================
# IDENTIDAD VISUAL (colores tomados del logo de Reymon Industrias)
# =====================================================================
GRIS = "#5A5A5A"
GRIS_OSC = "#3E3E3E"
ROJO = "#C8161D"
ROJO_OSC = "#A31217"
VERDE = "#1E9E4A"
VERDE_OSC = "#157A38"
FONDO = "#F6F6F6"      # mismo gris del fondo del logo
BLANCO = "#FFFFFF"
BORDE = "#DADADA"
TEXTO = "#2B2B2B"
TEXTO_SUAVE = "#767676"
NARANJA = "#E58A00"
PISTA = "#E9E9E9"      # fondo vacío de las barras de progreso

F_BASE = F_BOLD = F_PEQ = F_TITULO = F_GRANDE = None  # se definen al abrir la ventana


def definir_fuentes():
    global F_BASE, F_BOLD, F_PEQ, F_TITULO, F_GRANDE
    disponibles = set(tkfont.families())
    familia = "TkDefaultFont"
    for candidata in ("Segoe UI", "Helvetica Neue", "Ubuntu", "Arial"):
        if candidata in disponibles:
            familia = candidata
            break
    F_BASE = (familia, 11)
    F_BOLD = (familia, 11, "bold")
    F_PEQ = (familia, 10)
    F_TITULO = (familia, 20, "bold")
    F_GRANDE = (familia, 26, "bold")


def centrar(ventana, ancho, alto):
    ventana.update_idletasks()
    x = (ventana.winfo_screenwidth() - ancho) // 2
    y = max((ventana.winfo_screenheight() - alto) // 3, 0)
    ventana.geometry(f"{ancho}x{alto}+{x}+{y}")


def cargar_imagen(nombre):
    try:
        return tk.PhotoImage(file=ruta(nombre))
    except tk.TclError:
        return None


def configurar_estilos(root):
    st = ttk.Style(root)
    st.theme_use("clam")
    root.option_add("*TCombobox*Listbox.font", F_BASE)
    root.option_add("*TCombobox*Listbox.selectBackground", VERDE)

    st.configure(".", font=F_BASE, background=BLANCO, foreground=TEXTO)

    st.configure("TEntry", padding=7, fieldbackground=BLANCO, bordercolor=BORDE,
                 lightcolor=BORDE, darkcolor=BORDE)
    st.map("TEntry", bordercolor=[("focus", VERDE)], lightcolor=[("focus", VERDE)],
           darkcolor=[("focus", VERDE)])
    st.configure("TCombobox", padding=7, fieldbackground=BLANCO, bordercolor=BORDE,
                 lightcolor=BORDE, darkcolor=BORDE, arrowcolor=GRIS)
    st.map("TCombobox", fieldbackground=[("readonly", BLANCO)],
           bordercolor=[("focus", VERDE)])

    st.configure("Primary.TButton", background=ROJO, foreground="white", font=F_BOLD,
                 padding=(20, 10), borderwidth=0, focusthickness=0)
    st.map("Primary.TButton", background=[("active", ROJO_OSC), ("disabled", "#BBBBBB")])

    st.configure("Green.TButton", background=VERDE, foreground="white", font=F_BOLD,
                 padding=(20, 10), borderwidth=0, focusthickness=0)
    st.map("Green.TButton", background=[("active", VERDE_OSC)])

    st.configure("Secondary.TButton", background="#E4E4E4", foreground=TEXTO, font=F_BASE,
                 padding=(18, 9), borderwidth=0, focusthickness=0)
    st.map("Secondary.TButton", background=[("active", "#D3D3D3")])

    st.configure("Side.TButton", background=GRIS_OSC, foreground="#EDEDED", font=F_BASE,
                 padding=(22, 13), borderwidth=0, anchor="w", focusthickness=0)
    st.map("Side.TButton", background=[("active", GRIS)])
    st.configure("SideActive.TButton", background=ROJO, foreground="white", font=F_BOLD,
                 padding=(22, 13), borderwidth=0, anchor="w", focusthickness=0)
    st.map("SideActive.TButton", background=[("active", ROJO_OSC)])

    st.configure("Treeview", font=F_BASE, rowheight=34, background=BLANCO,
                 fieldbackground=BLANCO, bordercolor=BORDE, borderwidth=1)
    st.map("Treeview", background=[("selected", "#DCEFE3")], foreground=[("selected", TEXTO)])
    st.configure("Treeview.Heading", font=F_BOLD, background=GRIS, foreground="white",
                 relief="flat", padding=(8, 8))
    st.map("Treeview.Heading", background=[("active", GRIS_OSC)])

    st.configure("TNotebook", background=BLANCO, borderwidth=0)
    st.configure("TNotebook.Tab", font=F_BASE, padding=(16, 9), background="#E9E9E9")
    st.map("TNotebook.Tab", background=[("selected", BLANCO)],
           foreground=[("selected", ROJO)])


# ---------------------------------------------------------------------
# Piezas de interfaz reutilizables
# ---------------------------------------------------------------------
def barra_acento(parent, alto=5):
    """Franja verde/roja con los colores del logo."""
    barra = tk.Frame(parent, height=alto, bg=ROJO)
    tk.Frame(barra, bg=VERDE, height=alto, width=140).pack(side="left", fill="y")
    return barra


def tarjeta(parent):
    return tk.Frame(parent, bg=BLANCO, highlightbackground=BORDE, highlightthickness=1)


def etiqueta(parent, texto, primero=False):
    tk.Label(parent, text=texto, font=F_PEQ, bg=BLANCO, fg=TEXTO_SUAVE).pack(
        anchor="w", pady=(0 if primero else 12, 4))


def entrada(parent, ancho=46, **kw):
    e = ttk.Entry(parent, width=ancho, font=F_BASE, **kw)
    e.pack(anchor="w")
    return e


def combo(parent, valores, ancho=44):
    c = ttk.Combobox(parent, values=valores, state="readonly", width=ancho, font=F_BASE)
    c.pack(anchor="w")
    return c


def crear_tabla(parent, columnas, alto=10):
    """columnas: lista de (id, titulo, ancho, anchor)."""
    marco = tk.Frame(parent, bg=BLANCO)
    tabla = ttk.Treeview(marco, columns=[c[0] for c in columnas], show="headings",
                         height=alto, selectmode="browse")
    for cid, titulo, ancho, anclaje in columnas:
        tabla.heading(cid, text=titulo)
        tabla.column(cid, width=ancho, anchor=anclaje)
    barra = ttk.Scrollbar(marco, orient="vertical", command=tabla.yview)
    tabla.configure(yscrollcommand=barra.set)
    tabla.pack(side="left", fill="both", expand=True)
    barra.pack(side="right", fill="y")
    return marco, tabla


def poner_marca_agua(parent, imagen):
    """Logo difuminado en la esquina inferior derecha, DETRÁS del resto de widgets."""
    if not imagen:
        return None
    marca = tk.Label(parent, image=imagen, bg=FONDO, bd=0)
    marca.place(relx=1.0, rely=1.0, anchor="se", x=-16, y=-12)
    marca.lower()
    return marca


def poner_fondo(parent, imagen):
    """Imagen difuminada que cubre TODO el fondo de la página (centrada y detrás de todo)."""
    if not imagen:
        return None
    fondo = tk.Label(parent, image=imagen, bg=FONDO, bd=0, anchor="center")
    fondo.place(x=0, y=0, relwidth=1.0, relheight=1.0)
    fondo.lower()
    return fondo


# ---------------------------------------------------------------------
# Gráficas (dibujadas con Canvas, sin librerías externas)
# ---------------------------------------------------------------------
def pesos(valor):
    return f"${valor:,.0f}"


def color_avance(porcentaje):
    """Semáforo: verde hasta 80 %, naranja hasta 100 %, rojo si se pasa."""
    if porcentaje > 100:
        return ROJO
    if porcentaje > 80:
        return NARANJA
    return VERDE


def recortar(texto, maximo):
    return texto if len(texto) <= maximo else texto[:maximo - 1].rstrip() + "…"


class Kpi(tk.Frame):
    """Tarjetita con un título pequeño y un valor grande."""

    def __init__(self, master, titulo):
        super().__init__(master, bg=FONDO, highlightbackground=BORDE, highlightthickness=1)
        self.lbl_titulo = tk.Label(self, text=titulo, font=F_PEQ, bg=FONDO, fg=TEXTO_SUAVE)
        self.lbl_titulo.pack(anchor="w", padx=14, pady=(10, 0))
        self.lbl_valor = tk.Label(self, text="—", font=(F_TITULO[0], 20, "bold"),
                                  bg=FONDO, fg=GRIS_OSC)
        self.lbl_valor.pack(anchor="w", padx=16, pady=(0, 10))

    def poner(self, valor, color=GRIS_OSC, titulo=None):
        self.lbl_valor.config(text=valor, fg=color)
        if titulo:
            self.lbl_titulo.config(text=titulo)


class BarraProgreso(tk.Canvas):
    """Barra de porcentaje. Si se pasa del 100 % queda llena y en rojo."""

    def __init__(self, master):
        super().__init__(master, height=70, bg=BLANCO, highlightthickness=0)
        self._datos = None
        self.bind("<Configure>", lambda _e: self._dibujar())

    def actualizar(self, porcentaje, izquierda="", derecha="", vacio=""):
        self._datos = (porcentaje, izquierda, derecha, vacio)
        self._dibujar()

    def _dibujar(self):
        self.delete("all")
        if not self._datos:
            return
        pct, izq, der, vacio = self._datos
        w = max(self.winfo_width(), 240)
        x0, x1, y0, y1 = 2, w - 2, 30, 64
        self.create_rectangle(x0, y0, x1, y1, fill=PISTA, outline="")
        if pct is None:
            self.create_text(w / 2, (y0 + y1) / 2, text=vacio, font=F_PEQ, fill=TEXTO_SUAVE)
            return
        self.create_text(x0, 13, text=izq, anchor="w", font=F_BOLD, fill=GRIS_OSC)
        self.create_text(x1, 13, text=der, anchor="e", font=F_PEQ, fill=TEXTO_SUAVE)
        lleno = (x1 - x0) * min(pct, 100) / 100
        if lleno > 0:
            self.create_rectangle(x0, y0, x0 + lleno, y1, fill=color_avance(pct), outline="")
        etiqueta_pct = f"{pct:.0f} %" + ("  ·  ¡se pasó!" if pct > 100 else "")
        en_barra = lleno > 120
        self.create_text(x0 + lleno - 10 if en_barra else x0 + lleno + 10, (y0 + y1) / 2,
                         text=etiqueta_pct, anchor="e" if en_barra else "w",
                         font=F_BOLD, fill="white" if en_barra else GRIS_OSC)


class GraficoBarras(tk.Canvas):
    """Barras horizontales: filas = [(etiqueta, valor, texto_valor, color), ...]."""
    FILA = 30

    def __init__(self, master, vacio="Sin datos todavía."):
        super().__init__(master, height=40, bg=BLANCO, highlightthickness=0)
        self.filas = []
        self.vacio = vacio
        self.bind("<Configure>", lambda _e: self._dibujar())

    def actualizar(self, filas):
        self.filas = filas
        self.config(height=max(len(filas), 1) * self.FILA + 6)
        self._dibujar()

    def _dibujar(self):
        self.delete("all")
        w = max(self.winfo_width(), 320)
        if not self.filas:
            self.create_text(2, 18, text=self.vacio, anchor="w", font=F_BASE, fill=TEXTO_SUAVE)
            return
        x0, x1 = 190, w - 150
        maximo = max(f[1] for f in self.filas) or 1
        for i, (nombre, valor, texto, color) in enumerate(self.filas):
            yc = i * self.FILA + self.FILA / 2 + 2
            self.create_text(0, yc, text=recortar(nombre, 26), anchor="w",
                             font=F_PEQ, fill=TEXTO)
            largo = max((x1 - x0) * valor / maximo, 3)
            self.create_rectangle(x0, yc - 9, x0 + largo, yc + 9, fill=color, outline="")
            self.create_text(x0 + largo + 8, yc, text=texto, anchor="w",
                             font=F_PEQ, fill=GRIS_OSC)


class LineaTiempo(tk.Canvas):
    """Gantt sencillo: cada actividad es un tramo que empieza donde terminó la anterior."""
    FILA = 30
    TOPE = 26

    def __init__(self, master, alto=200):
        super().__init__(master, height=alto, bg=BLANCO, highlightthickness=0)
        self._datos = ([], 0.0)
        self.bind("<Configure>", lambda _e: self._dibujar())
        # rueda del mouse (Windows/Mac y Linux)
        self.bind("<MouseWheel>", lambda e: self.yview_scroll(-1 if e.delta > 0 else 1, "units"))
        self.bind("<Button-4>", lambda _e: self.yview_scroll(-1, "units"))
        self.bind("<Button-5>", lambda _e: self.yview_scroll(1, "units"))

    def actualizar(self, actividades, estimado):
        self._datos = (actividades, estimado)
        self.yview_moveto(0)
        self._dibujar()

    def _dibujar(self):
        self.delete("all")
        acts, estimado = self._datos
        w = max(self.winfo_width(), 420)
        if not acts:
            self.create_text(w / 2, 50, font=F_BASE, fill=TEXTO_SUAVE,
                             text="Aún no hay actividades registradas para este proyecto.")
            self.config(scrollregion=(0, 0, w, 100))
            return

        total = sum(a["horas"] for a in acts)
        escala = max(total, estimado) or 1
        x0, x1 = 200, w - 80
        ancho = x1 - x0
        alto = self.TOPE + len(acts) * self.FILA + 22

        # cuadrícula con las horas en el eje superior
        for k in range(5):
            x = x0 + ancho * k / 4
            self.create_line(x, self.TOPE - 4, x, alto - 18, fill="#EDEDED")
            self.create_text(x, 10, text=f"{escala * k / 4:g} h", font=F_PEQ, fill=TEXTO_SUAVE)

        acumulado = 0
        for i, act in enumerate(acts):
            yc = self.TOPE + i * self.FILA + self.FILA / 2
            self.create_text(0, yc, anchor="w", font=F_PEQ, fill=TEXTO,
                             text=f"{i + 1}. {recortar(act['descripcion'], 24)}")
            xi = x0 + ancho * acumulado / escala
            xf = x0 + ancho * (acumulado + act["horas"]) / escala
            self.create_rectangle(xi, yc - 9, max(xf, xi + 3), yc + 9, outline="",
                                  fill=VERDE if i % 2 == 0 else "#62B97F")
            self.create_text(max(xf, xi + 3) + 6, yc, anchor="w", font=F_PEQ,
                             fill=GRIS_OSC, text=f"{act['horas']:g} h")
            acumulado += act["horas"]

        if estimado > 0:   # línea roja punteada = horas estimadas
            xe = x0 + ancho * estimado / escala
            self.create_line(xe, self.TOPE - 4, xe, alto - 18, fill=ROJO, width=2, dash=(5, 3))
            self.create_text(min(xe, w - 60), alto - 8, text=f"Estimado: {estimado:g} h",
                             font=F_PEQ, fill=ROJO)
        self.config(scrollregion=(0, 0, w, alto))


def crear_linea_tiempo(parent, alto=200):
    marco = tk.Frame(parent, bg=BLANCO)
    lienzo = LineaTiempo(marco, alto)
    barra = ttk.Scrollbar(marco, orient="vertical", command=lienzo.yview)
    lienzo.configure(yscrollcommand=barra.set)
    lienzo.pack(side="left", fill="both", expand=True)
    barra.pack(side="right", fill="y")
    return marco, lienzo


# =====================================================================
# PANTALLA DE INGRESO
# =====================================================================
class PantallaLogin(tk.Frame):
    def __init__(self, master, app):
        super().__init__(master, bg=FONDO)
        self.app = app

        poner_marca_agua(self, app.img_marca)
        barra_acento(self).pack(fill="x", side="top")

        centro = tk.Frame(self, bg=FONDO)
        centro.place(relx=0.5, rely=0.5, anchor="center")

        if app.img_login:
            tk.Label(centro, image=app.img_login, bg=FONDO).pack(pady=(0, 6))
        else:
            tk.Label(centro, text="REYMON INDUSTRIAS", font=F_GRANDE, bg=FONDO,
                     fg=GRIS).pack(pady=(0, 6))

        tk.Label(centro, text="Sistema de Gestión de Planta", font=(F_TITULO[0], 15),
                 bg=FONDO, fg=GRIS).pack(pady=(0, 18))

        card = tarjeta(centro)
        card.pack()
        cuerpo = tk.Frame(card, bg=BLANCO)
        cuerpo.pack(padx=40, pady=32)

        tk.Label(cuerpo, text="Iniciar sesión", font=(F_TITULO[0], 16, "bold"),
                 bg=BLANCO, fg=GRIS_OSC).pack(anchor="w", pady=(0, 14))

        etiqueta(cuerpo, "Nombre de usuario", primero=True)
        self.e_usuario = entrada(cuerpo, 38)
        etiqueta(cuerpo, "Contraseña")
        self.e_clave = entrada(cuerpo, 38, show="•")

        self.estado = tk.Label(cuerpo, text="", font=F_PEQ, bg=BLANCO, fg=ROJO,
                               wraplength=300, justify="left")
        self.estado.pack(anchor="w", pady=(10, 0))

        ttk.Button(cuerpo, text="Ingresar", style="Primary.TButton",
                   command=self.ingresar).pack(fill="x", pady=(14, 8))
        ttk.Button(cuerpo, text="Registrar nuevo usuario", style="Secondary.TButton",
                   command=self.abrir_registro).pack(fill="x")

        tk.Label(self, text="Reymon Industrias · Gestión de proyectos, bodega y herramientas",
                 font=F_PEQ, bg=FONDO, fg=TEXTO_SUAVE).pack(side="bottom", pady=14)

        self.e_usuario.focus_set()
        self.e_clave.bind("<Return>", lambda _e: self.ingresar())
        self.e_usuario.bind("<Return>", lambda _e: self.e_clave.focus_set())

    def ingresar(self):
        sesion = iniciar_sesion(self.e_usuario.get(), self.e_clave.get())
        if sesion:
            self.app.mostrar_principal(sesion)
        else:
            self.estado.config(text="Nombre de usuario o contraseña incorrectos.", fg=ROJO)
            self.e_clave.delete(0, "end")

    def abrir_registro(self):
        DialogoRegistro(self.winfo_toplevel(), self)


class DialogoRegistro(tk.Toplevel):
    def __init__(self, master, login):
        super().__init__(master, bg=BLANCO)
        self.login = login
        self.title("Registro de usuario")
        self.resizable(False, False)
        self.transient(master)

        cuerpo = tk.Frame(self, bg=BLANCO)
        cuerpo.pack(padx=34, pady=28)

        tk.Label(cuerpo, text="Registro de usuario", font=(F_TITULO[0], 16, "bold"),
                 bg=BLANCO, fg=GRIS_OSC).pack(anchor="w", pady=(0, 12))

        etiqueta(cuerpo, "Nombre de usuario", primero=True)
        self.e_nombre = entrada(cuerpo, 36)
        etiqueta(cuerpo, "Cargo")
        self.c_cargo = combo(cuerpo, [c.capitalize() for c in CARGOS], 34)
        self.c_cargo.current(0)
        etiqueta(cuerpo, "Contraseña")
        self.e_clave = entrada(cuerpo, 36, show="•")

        self.estado = tk.Label(cuerpo, text="", font=F_PEQ, bg=BLANCO, wraplength=320,
                               justify="left")
        self.estado.pack(anchor="w", pady=(10, 0))

        botones = tk.Frame(cuerpo, bg=BLANCO)
        botones.pack(fill="x", pady=(14, 0))
        ttk.Button(botones, text="Registrar", style="Primary.TButton",
                   command=self.registrar).pack(side="left")
        ttk.Button(botones, text="Cerrar", style="Secondary.TButton",
                   command=self.destroy).pack(side="right")

        centrar(self, 420, 470)
        self.e_nombre.focus_set()
        try:
            self.wait_visibility()
            self.grab_set()
        except tk.TclError:
            pass

    def registrar(self):
        cargo = CARGOS[self.c_cargo.current()]
        ok, mensaje = registrar_usuario(self.e_nombre.get(), self.e_clave.get(), cargo)
        self.estado.config(text=("✔  " if ok else "✖  ") + mensaje,
                           fg=VERDE_OSC if ok else ROJO)
        if ok:
            # deja el usuario listo en la pantalla de ingreso
            self.login.e_usuario.delete(0, "end")
            self.login.e_usuario.insert(0, self.e_nombre.get().strip())
            self.e_nombre.delete(0, "end")
            self.e_clave.delete(0, "end")


# =====================================================================
# PÁGINAS DEL MENÚ DE OPERACIONES
# =====================================================================
class Pagina(tk.Frame):
    """Base: título, tarjeta blanca para el contenido y línea de estado."""

    def __init__(self, master, app, titulo, subtitulo="", fondo=None):
        super().__init__(master, bg=FONDO)
        self.app = app
        # si la página trae su propia imagen de fondo se usa esa; si no, el logo en la esquina
        if fondo:
            self.marca = poner_fondo(self, fondo)
        else:
            self.marca = poner_marca_agua(self, app.img_marca)
        tk.Label(self, text=titulo, font=F_TITULO, bg=FONDO, fg=GRIS_OSC).pack(anchor="w")
        tk.Label(self, text=subtitulo, font=F_BASE, bg=FONDO, fg=TEXTO_SUAVE).pack(
            anchor="w", pady=(2, 12))
        self.tarjeta = tarjeta(self)
        self.tarjeta.pack(anchor="w")
        self.cuerpo = tk.Frame(self.tarjeta, bg=BLANCO)
        self.cuerpo.pack(padx=40, pady=24)
        # sin fill="x": así la etiqueta solo ocupa su texto y no tapa la marca de agua
        self.estado = tk.Label(self, text="", font=F_BASE, bg=FONDO, anchor="w",
                               justify="left", wraplength=720)
        self.estado.pack(anchor="w", pady=(14, 0))

    def msg(self, texto, ok=True):
        self.estado.config(text=("✔  " if ok else "✖  ") + texto,
                           fg=VERDE_OSC if ok else ROJO)

    def nombres_proyectos(self):
        return list(proyectos.keys())


class PaginaDenegada(Pagina):
    def __init__(self, master, app, requerido):
        super().__init__(master, app, "Acceso denegado",
                         "No cuentas con el rol requerido para esta opción.")
        tk.Label(self.cuerpo, text="🔒", font=(F_TITULO[0], 40), bg=BLANCO).pack()
        tk.Label(self.cuerpo, text=f"Esta opción está reservada para:\n{requerido}",
                 font=F_BASE, bg=BLANCO, fg=TEXTO, justify="center").pack(pady=(8, 0))


class PaginaCrearProyecto(Pagina):
    def __init__(self, master, app):
        super().__init__(master, app, "Crear proyecto",
                         "Registra un nuevo proyecto de la planta.",
                         fondo=app.img_fondo_proyecto)
        etiqueta(self.cuerpo, "Nombre del nuevo proyecto", primero=True)
        self.e_nombre = entrada(self.cuerpo, 66)
        self.e_nombre.focus_set()
        self.e_nombre.bind("<Return>", lambda _e: self.crear())
        ttk.Button(self.cuerpo, text="Crear proyecto", style="Primary.TButton",
                   command=self.crear).pack(anchor="w", pady=(18, 0))

        tk.Label(self.cuerpo, text="Proyectos existentes", font=F_BOLD, bg=BLANCO,
                 fg=GRIS_OSC).pack(anchor="w", pady=(24, 6))
        marco, self.tabla = crear_tabla(self.cuerpo, [("p", "Proyecto", 580, "w")], alto=6)
        marco.pack(anchor="w")
        self.refrescar_lista()

    def refrescar_lista(self):
        self.tabla.delete(*self.tabla.get_children())
        for nombre in proyectos:
            self.tabla.insert("", "end", values=(nombre,))

    def crear(self):
        nombre = self.e_nombre.get().strip()
        ok, mensaje = crear_proyecto(nombre)
        self.msg(mensaje, ok)
        if not ok:
            return
        self.e_nombre.delete(0, "end")
        self.refrescar_lista()
        if messagebox.askyesno(
                "Recursos del proyecto",
                "¿Desea registrar herramientas y consumibles para este proyecto ahora?",
                parent=self.winfo_toplevel()):
            DialogoRecursos(self.winfo_toplevel(), nombre, self.app.usuario["nombre"])


class PaginaActividad(Pagina):
    def __init__(self, master, app):
        super().__init__(master, app, "Registrar actividad",
                         "Registra las horas y el consumible usado en una actividad del proyecto.")
        self.items = list(inventario_bodega.keys())

        etiqueta(self.cuerpo, "Proyecto", primero=True)
        self.c_proy = combo(self.cuerpo, self.nombres_proyectos(), 64)
        etiqueta(self.cuerpo, "Descripción de la actividad")
        self.e_desc = entrada(self.cuerpo, 66)
        etiqueta(self.cuerpo, "Horas invertidas en la actividad")
        self.e_horas = entrada(self.cuerpo, 28)

        etiqueta(self.cuerpo, "Consumible de bodega (opcional)")
        valores = ["(Sin consumible)"] + [
            f"{i}  —  {inventario_bodega[i]} unidades disponibles" for i in self.items]
        self.c_item = combo(self.cuerpo, valores, 64)
        self.c_item.current(0)
        etiqueta(self.cuerpo, "Cantidad requerida del consumible")
        self.e_cant = entrada(self.cuerpo, 28)

        ttk.Button(self.cuerpo, text="Registrar actividad", style="Primary.TButton",
                   command=self.registrar).pack(anchor="w", pady=(20, 0))

    def registrar(self):
        idx = self.c_item.current()
        item = self.items[idx - 1] if idx > 0 else ""
        ok, mensaje = registrar_actividad(self.c_proy.get(), self.e_desc.get(),
                                          self.e_horas.get(), item, self.e_cant.get())
        self.msg(mensaje, ok)
        if ok:
            self.app.mostrar_pagina("actividad")
            self.app.pagina_actual.msg(mensaje, True)


class PaginaCostoEsperado(Pagina):
    def __init__(self, master, app):
        super().__init__(master, app, "Costo esperado del proyecto",
                         "Asigna el costo esperado a un proyecto.")
        etiqueta(self.cuerpo, "Proyecto", primero=True)
        self.c_proy = combo(self.cuerpo, self.nombres_proyectos(), 64)
        etiqueta(self.cuerpo, "Costo esperado del proyecto ($)")
        self.e_costo = entrada(self.cuerpo, 34)
        etiqueta(self.cuerpo, "Horas estimadas del proyecto (opcional, para la gráfica de tiempos)")
        self.e_horas = entrada(self.cuerpo, 34)
        ttk.Button(self.cuerpo, text="Asignar", style="Primary.TButton",
                   command=self.asignar).pack(anchor="w", pady=(20, 0))

    def asignar(self):
        nombre = self.c_proy.get()
        costo_txt = self.e_costo.get().strip()
        horas_txt = self.e_horas.get().strip()
        if not costo_txt and not horas_txt:
            self.msg("Ingrese el costo esperado, las horas estimadas o ambos.", False)
            return
        # se valida todo antes de guardar, para no dejar la mitad asignada
        if costo_txt and leer_decimal(costo_txt) is None:
            self.msg("Valor numérico inválido en el costo.", False)
            return
        horas = leer_decimal(horas_txt) if horas_txt else 0
        if horas is None or horas < 0:
            self.msg("Ingrese una cantidad de horas válida.", False)
            return

        mensajes = []
        for funcion, texto in ((asignar_costo_esperado, costo_txt),
                               (asignar_horas_estimadas, horas_txt)):
            if texto:
                ok, mensaje = funcion(nombre, texto)
                if not ok:
                    self.msg(mensaje, False)
                    return
                mensajes.append(mensaje)
        self.msg("  ".join(mensajes), True)
        self.e_costo.delete(0, "end")
        self.e_horas.delete(0, "end")


class PaginaConsultaValor(Pagina):
    """Consulta de un solo dato por proyecto (costos o tiempos)."""

    def __init__(self, master, app, titulo, subtitulo, rotulo, funcion_valor):
        super().__init__(master, app, titulo, subtitulo)
        self.rotulo = rotulo
        self.funcion_valor = funcion_valor
        etiqueta(self.cuerpo, "Proyecto a consultar", primero=True)
        self.c_proy = combo(self.cuerpo, self.nombres_proyectos(), 48)
        self.c_proy.bind("<<ComboboxSelected>>", lambda _e: self.consultar())
        ttk.Button(self.cuerpo, text="Consultar", style="Primary.TButton",
                   command=self.consultar).pack(anchor="w", pady=(18, 0))

        self.resultado = tk.Frame(self.cuerpo, bg="#EEF7F1", highlightbackground="#BFE0CB",
                                  highlightthickness=1)
        self.lbl_rotulo = tk.Label(self.resultado, text="", font=F_PEQ, bg="#EEF7F1",
                                   fg=TEXTO_SUAVE)
        self.lbl_rotulo.pack(anchor="w", padx=22, pady=(14, 0))
        self.lbl_valor = tk.Label(self.resultado, text="", font=F_GRANDE, bg="#EEF7F1",
                                  fg=VERDE_OSC)
        self.lbl_valor.pack(anchor="w", padx=22, pady=(0, 14))

    def consultar(self):
        nombre = self.c_proy.get()
        if nombre not in proyectos:
            self.msg("Seleccione un proyecto existente.", False)
            return
        self.estado.config(text="")
        self.lbl_rotulo.config(text=f"{self.rotulo} — {nombre}")
        self.lbl_valor.config(text=self.funcion_valor(proyectos[nombre]))
        self.resultado.pack(anchor="w", fill="x", pady=(20, 0))


class PaginaGraficoCostos(Pagina):
    """Costo real vs costo esperado, con barra de porcentaje y desglose del gasto."""

    def __init__(self, master, app):
        super().__init__(master, app, "Consultar costos",
                         "Cuánto va gastado de cada proyecto frente a lo que se esperaba.")
        self.tarjeta.pack_configure(fill="x")
        self.cuerpo.pack_configure(fill="x", pady=16)

        etiqueta(self.cuerpo, "Proyecto a consultar", primero=True)
        self.c_proy = combo(self.cuerpo, self.nombres_proyectos(), 64)
        self.c_proy.bind("<<ComboboxSelected>>", lambda _e: self.consultar())

        self.resultado = tk.Frame(self.cuerpo, bg=BLANCO)
        fila = tk.Frame(self.resultado, bg=BLANCO)
        fila.pack(fill="x", pady=(16, 0))
        self.k_esperado = Kpi(fila, "Costo esperado")
        self.k_real = Kpi(fila, "Costo real acumulado")
        self.k_dif = Kpi(fila, "Presupuesto disponible")
        for i, k in enumerate((self.k_esperado, self.k_real, self.k_dif)):
            k.grid(row=0, column=i, sticky="ew", padx=(0 if i == 0 else 10, 0))
            fila.columnconfigure(i, weight=1, uniform="kpi")

        self.barra = BarraProgreso(self.resultado)
        self.barra.pack(fill="x", pady=(14, 0))

        tk.Label(self.resultado, text="¿En qué se ha ido la plata?", font=F_BOLD,
                 bg=BLANCO, fg=GRIS_OSC).pack(anchor="w", pady=(10, 4))
        self.grafico = GraficoBarras(self.resultado, "Aún no hay gastos registrados.")
        self.grafico.pack(fill="x")

    def consultar(self):
        nombre = self.c_proy.get()
        if nombre not in proyectos:
            self.msg("Seleccione un proyecto existente.", False)
            return
        self.estado.config(text="")
        datos = proyectos[nombre]
        esperado = datos["costo_esperado"]
        real, desglose = calcular_costo_real(datos)

        self.k_real.poner(pesos(real))
        if esperado > 0:
            pct = real / esperado * 100
            self.k_esperado.poner(pesos(esperado))
            if esperado >= real:
                self.k_dif.poner(pesos(esperado - real), VERDE_OSC, "Presupuesto disponible")
            else:
                self.k_dif.poner(pesos(real - esperado), ROJO, "Excedido en")
            self.barra.actualizar(pct, "Avance del presupuesto",
                                  f"{pesos(real)} de {pesos(esperado)}")
        else:
            self.k_esperado.poner("Sin asignar", TEXTO_SUAVE)
            self.k_dif.poner("—", TEXTO_SUAVE, "Presupuesto disponible")
            self.barra.actualizar(None, vacio="Asigna un costo esperado a este proyecto "
                                              "(opción 3) para ver el porcentaje.")

        filas = []
        for concepto, valor in sorted(desglose.items(), key=lambda kv: kv[1], reverse=True):
            if valor > 0:
                color = GRIS if concepto == "Mano de obra" else VERDE
                filas.append((concepto, valor,
                              f"{pesos(valor)}  ({valor / real * 100:.0f} %)", color))
        self.grafico.actualizar(filas)
        self.resultado.pack(fill="x")


class PaginaGraficoTiempos(Pagina):
    """Horas registradas vs horas estimadas, con barra de porcentaje y línea de tiempo."""

    def __init__(self, master, app):
        super().__init__(master, app, "Tiempos de proyecto",
                         "Horas trabajadas en cada proyecto y cómo se fueron repartiendo.")
        self.tarjeta.pack_configure(fill="x")
        self.cuerpo.pack_configure(fill="x")

        etiqueta(self.cuerpo, "Proyecto a consultar", primero=True)
        self.c_proy = combo(self.cuerpo, self.nombres_proyectos(), 48)
        self.c_proy.bind("<<ComboboxSelected>>", lambda _e: self.consultar())

        self.resultado = tk.Frame(self.cuerpo, bg=BLANCO)
        fila = tk.Frame(self.resultado, bg=BLANCO)
        fila.pack(fill="x", pady=(16, 0))
        self.k_total = Kpi(fila, "Horas registradas")
        self.k_estimado = Kpi(fila, "Horas estimadas")
        self.k_dif = Kpi(fila, "Horas restantes")
        for i, k in enumerate((self.k_total, self.k_estimado, self.k_dif)):
            k.grid(row=0, column=i, sticky="ew", padx=(0 if i == 0 else 10, 0))
            fila.columnconfigure(i, weight=1, uniform="kpi")

        self.barra = BarraProgreso(self.resultado)
        self.barra.pack(fill="x", pady=(14, 0))

        tk.Label(self.resultado, text="Línea de tiempo de actividades", font=F_BOLD,
                 bg=BLANCO, fg=GRIS_OSC).pack(anchor="w", pady=(10, 4))
        marco, self.linea = crear_linea_tiempo(self.resultado, 190)
        marco.pack(fill="x")

    def consultar(self):
        nombre = self.c_proy.get()
        if nombre not in proyectos:
            self.msg("Seleccione un proyecto existente.", False)
            return
        self.estado.config(text="")
        datos = proyectos[nombre]
        total = datos["tiempo_total"]
        estimado = datos.get("tiempo_estimado", 0.0)

        self.k_total.poner(f"{total:g} h")
        if estimado > 0:
            pct = total / estimado * 100
            self.k_estimado.poner(f"{estimado:g} h")
            if estimado >= total:
                self.k_dif.poner(f"{estimado - total:g} h", VERDE_OSC, "Horas restantes")
            else:
                self.k_dif.poner(f"{total - estimado:g} h", ROJO, "Horas de más")
            self.barra.actualizar(pct, "Avance del tiempo estimado",
                                  f"{total:g} h de {estimado:g} h")
        else:
            self.k_estimado.poner("Sin asignar", TEXTO_SUAVE)
            self.k_dif.poner("—", TEXTO_SUAVE, "Horas restantes")
            self.barra.actualizar(None, vacio="Asigna las horas estimadas a este proyecto "
                                              "(opción 3) para ver el porcentaje.")

        self.linea.actualizar(datos["actividades"], estimado)
        self.resultado.pack(fill="x")


class PaginaConsumibles(Pagina):
    def __init__(self, master, app):
        super().__init__(master, app, "Consumibles por proyecto",
                         "Cantidad de consumibles utilizados en cada proyecto.")
        etiqueta(self.cuerpo, "Proyecto a consultar", primero=True)
        self.c_proy = combo(self.cuerpo, self.nombres_proyectos(), 64)
        self.c_proy.bind("<<ComboboxSelected>>", lambda _e: self.consultar())
        marco, self.tabla = crear_tabla(
            self.cuerpo, [("item", "Consumible", 400, "w"), ("cant", "Unidades", 170, "e")],
            alto=8)
        marco.pack(anchor="w", pady=(18, 0))

    def consultar(self):
        self.tabla.delete(*self.tabla.get_children())
        nombre = self.c_proy.get()
        if nombre not in proyectos:
            return
        consumos = proyectos[nombre]["consumibles"]
        if not consumos:
            self.msg("No se han registrado consumibles para este proyecto.", True)
            return
        self.estado.config(text="")
        for item, cant in consumos.items():
            self.tabla.insert("", "end", values=(item, f"{cant} unidades"))


class PaginaBodega(Pagina):
    def __init__(self, master, app):
        super().__init__(master, app, "Inventario de bodega",
                         "Existencias actuales de consumibles.")
        marco, tabla = crear_tabla(
            self.cuerpo, [("item", "Consumible", 400, "w"), ("cant", "Disponible", 170, "e")],
            alto=9)
        marco.pack(anchor="w")
        for item, cant in inventario_bodega.items():
            tabla.insert("", "end", values=(item, f"{cant} unidades"))


# =====================================================================
# VENTANA DE REGISTRO DE HERRAMIENTAS Y CONSUMIBLES DEL PROYECTO
# =====================================================================
LIMITADAS = {
    "Soldador": "soldador",
    "Pulidora": "pulidora",
    "Compresor de pintura": "compresor de pintura",
}
OPCIONES_HERRAMIENTA = list(LIMITADAS) + ["Herramienta de mano", "Taladro", "Otra herramienta"]
FALLAS = ["No enciende", "Sonido fuera de lo normal", "Corto eléctrico", "Otro"]


class DialogoRecursos(tk.Toplevel):
    def __init__(self, master, nombre_p, usuario):
        super().__init__(master, bg=BLANCO)
        self.nombre_p = nombre_p
        self.usuario = usuario
        self.title(f"Herramientas y consumibles — {nombre_p}")
        self.resizable(False, False)
        self.transient(master)

        cab = tk.Frame(self, bg=FONDO)
        cab.pack(fill="x")
        tk.Label(cab, text="Herramientas y consumibles", font=(F_TITULO[0], 16, "bold"),
                 bg=FONDO, fg=GRIS_OSC).pack(anchor="w", padx=24, pady=(16, 0))
        tk.Label(cab, text=f"Proyecto: {nombre_p}", font=F_BASE, bg=FONDO,
                 fg=TEXTO_SUAVE).pack(anchor="w", padx=24, pady=(0, 14))
        barra_acento(self, 4).pack(fill="x")

        self.libreta = ttk.Notebook(self)
        self.libreta.pack(fill="both", expand=True, padx=18, pady=(14, 0))
        self._tab_herramienta()
        self._tab_consumible()
        self._tab_reporte()

        self.estado = tk.Label(self, text="", font=F_BASE, bg=BLANCO, anchor="w",
                               justify="left", wraplength=560)
        self.estado.pack(fill="x", padx=24, pady=(10, 0))

        pie = tk.Frame(self, bg=BLANCO)
        pie.pack(fill="x", padx=24, pady=(8, 18))
        ttk.Button(pie, text="Terminar", style="Green.TButton",
                   command=self.destroy).pack(side="right")

        centrar(self, 640, 640)
        try:
            self.wait_visibility()
            self.grab_set()
        except tk.TclError:
            pass

    def msg(self, texto, ok=True):
        self.estado.config(text=("✔  " if ok else "✖  ") + texto,
                           fg=VERDE_OSC if ok else ROJO)

    def _nueva_tab(self, titulo):
        marco = tk.Frame(self.libreta, bg=BLANCO)
        self.libreta.add(marco, text=titulo)
        cuerpo = tk.Frame(marco, bg=BLANCO)
        cuerpo.pack(padx=22, pady=18, anchor="w")
        return cuerpo

    # ---------------- herramienta a utilizar ----------------
    def _tab_herramienta(self):
        c = self._nueva_tab("Herramienta a utilizar")
        etiqueta(c, "Herramienta", primero=True)
        self.c_herr = combo(c, OPCIONES_HERRAMIENTA, 40)
        self.c_herr.current(0)
        self.c_herr.bind("<<ComboboxSelected>>", lambda _e: self._actualizar_herramienta())

        self.lbl_disp_herr = tk.Label(c, text="", font=F_BOLD, bg=BLANCO, fg=VERDE_OSC)
        self.lbl_disp_herr.pack(anchor="w", pady=(8, 0))

        etiqueta(c, "Cantidad a utilizar")
        self.e_cant_herr = entrada(c, 14)
        etiqueta(c, "Nombre de la herramienta (solo si elige «Otra herramienta»)")
        self.e_otra_herr = entrada(c, 40)

        ttk.Button(c, text="Registrar herramienta", style="Primary.TButton",
                   command=self.registrar_herramienta).pack(anchor="w", pady=(18, 0))
        self._actualizar_herramienta()

    def _actualizar_herramienta(self):
        sel = self.c_herr.get()
        self.e_cant_herr.config(state="normal")
        self.e_otra_herr.config(state="normal")
        self.e_cant_herr.delete(0, "end")
        self.e_cant_herr.insert(0, "1")
        if sel in LIMITADAS:
            disp = inventario_herramientas.get(LIMITADAS[sel], 0)
            self.lbl_disp_herr.config(text=f"Cantidad de {sel.lower()}(es) disponibles: {disp}")
            self.e_otra_herr.config(state="disabled")
        elif sel == "Otra herramienta":
            self.lbl_disp_herr.config(text="")
            self.e_cant_herr.config(state="disabled")
        else:
            self.lbl_disp_herr.config(text="")
            self.e_cant_herr.config(state="disabled")
            self.e_otra_herr.config(state="disabled")

    def registrar_herramienta(self):
        sel = self.c_herr.get()
        if sel in LIMITADAS:
            herramienta = LIMITADAS[sel]
            limitada = True
            cantidad = leer_entero_positivo(self.e_cant_herr.get())
            if cantidad is None:
                self.msg("La cantidad debe ser un número mayor que cero.", False)
                return
        elif sel == "Otra herramienta":
            herramienta = self.e_otra_herr.get().strip()
            limitada, cantidad = False, 1
        elif sel:
            herramienta = sel.lower()
            limitada, cantidad = False, 1
        else:
            self.msg("Seleccione una herramienta.", False)
            return
        ok, mensaje = registrar_herramienta(self.nombre_p, self.usuario, herramienta,
                                            cantidad, limitada)
        self.msg(mensaje, ok)
        if ok:
            self._actualizar_herramienta()

    # ---------------- consumibles ----------------
    def _tab_consumible(self):
        c = self._nueva_tab("Consumibles")
        self.items_bodega = list(inventario_bodega.keys())
        etiqueta(c, "Consumible", primero=True)
        self.c_cons = combo(c, self.items_bodega, 40)
        self.c_cons.bind("<<ComboboxSelected>>", lambda _e: self._actualizar_consumible())

        self.lbl_disp_cons = tk.Label(c, text="", font=F_BOLD, bg=BLANCO, fg=VERDE_OSC)
        self.lbl_disp_cons.pack(anchor="w", pady=(8, 0))

        self.lbl_detalle = tk.Label(c, text="Detalle (opcional)", font=F_PEQ, bg=BLANCO,
                                    fg=TEXTO_SUAVE)
        self.lbl_detalle.pack(anchor="w", pady=(12, 4))
        self.e_detalle = entrada(c, 40)
        etiqueta(c, "Cantidad a utilizar")
        self.e_cant_cons = entrada(c, 14)

        ttk.Button(c, text="Registrar consumible", style="Primary.TButton",
                   command=self.registrar_consumible).pack(anchor="w", pady=(18, 0))

    def _actualizar_consumible(self):
        item = self.c_cons.get()
        if item in inventario_bodega:
            self.lbl_disp_cons.config(
                text=f"Cantidad disponible de '{item}': {inventario_bodega[item]}")
        if item == "Brocas":
            self.lbl_detalle.config(text="Medida de la broca (ej. 1/4\", 6 mm)")
        elif item == "Electrodos":
            self.lbl_detalle.config(text="Característica de la soldadura (ej. 6011, 7018)")
        else:
            self.lbl_detalle.config(text="Detalle (opcional)")

    def registrar_consumible(self):
        item = self.c_cons.get()
        if not item:
            self.msg("Seleccione un consumible.", False)
            return
        cantidad = leer_entero_positivo(self.e_cant_cons.get())
        if cantidad is None:
            self.msg("La cantidad debe ser un número mayor que cero.", False)
            return
        ok, mensaje = registrar_consumible(self.nombre_p, self.usuario, item, cantidad,
                                           self.e_detalle.get().strip())
        self.msg(mensaje, ok)
        if ok:
            self.e_cant_cons.delete(0, "end")
            self.e_detalle.delete(0, "end")
            self._actualizar_consumible()

    # ---------------- reporte de herramienta en mal estado ----------------
    def _tab_reporte(self):
        c = self._nueva_tab("Reportar herramienta en mal estado")
        etiqueta(c, "¿Qué herramienta presenta el problema?", primero=True)
        self.e_herr_mala = entrada(c, 40)
        etiqueta(c, "Tipo de falla")
        self.c_falla = combo(c, FALLAS, 38)
        self.c_falla.current(0)
        self.c_falla.bind("<<ComboboxSelected>>", lambda _e: self._actualizar_falla())
        etiqueta(c, "Describa la falla (solo si elige «Otro»)")
        self.e_falla = entrada(c, 40)
        self.e_falla.config(state="disabled")
        ttk.Button(c, text="Enviar reporte", style="Primary.TButton",
                   command=self.enviar_reporte).pack(anchor="w", pady=(18, 0))

    def _actualizar_falla(self):
        self.e_falla.config(state="normal" if self.c_falla.get() == "Otro" else "disabled")

    def enviar_reporte(self):
        sel = self.c_falla.get()
        if sel == "Otro":
            falla = self.e_falla.get().strip() or "sin descripción"
        else:
            falla = sel.lower()
        ok, mensaje = reportar_herramienta_mal_estado(
            self.nombre_p, self.usuario, self.e_herr_mala.get(), falla)
        self.msg(mensaje, ok)
        if ok:
            self.e_herr_mala.delete(0, "end")


# =====================================================================
# PANTALLA PRINCIPAL (ENCABEZADO + MENÚ LATERAL + CONTENIDO)
# =====================================================================
class PantallaPrincipal(tk.Frame):
    # clave, texto del menú, roles permitidos (None = todos), texto del requerido
    OPCIONES = [
        ("crear", "1   Crear proyecto", None, None),
        ("actividad", "2   Registrar actividad", None, None),
        ("costo", "3   Costo esperado", ["ingeniero de proyectos"], "Ingeniero de proyectos"),
        ("costos", "4   Consultar costos", ["gerente"], "Gerente"),
        ("tiempos", "5   Tiempos de proyecto",
         ["gerente", "ingeniero de proyectos", "jefe de planta"],
         "Gerente, Ingeniero de proyectos o Jefe de planta"),
        ("consumibles", "6   Consumibles por proyecto", None, None),
        ("bodega", "7   Inventario de bodega", None, None),
    ]

    def __init__(self, master, app):
        super().__init__(master, bg=FONDO)
        self.app = app
        self.pagina_actual = None
        self.botones = {}

        # ---- encabezado con logo ----
        cab = tk.Frame(self, bg=FONDO)
        cab.pack(fill="x")
        if app.img_header:
            tk.Label(cab, image=app.img_header, bg=FONDO).pack(side="left", padx=(20, 0), pady=8)
        else:
            tk.Label(cab, text="REYMON INDUSTRIAS", font=F_TITULO, bg=FONDO,
                     fg=GRIS).pack(side="left", padx=20, pady=14)

        derecha = tk.Frame(cab, bg=FONDO)
        derecha.pack(side="right", padx=22)
        ttk.Button(derecha, text="Cerrar sesión", style="Secondary.TButton",
                   command=app.cerrar_sesion).pack(side="right")
        info = tk.Frame(derecha, bg=FONDO)
        info.pack(side="right", padx=(0, 18))
        tk.Label(info, text=app.usuario["nombre"], font=F_BOLD, bg=FONDO,
                 fg=GRIS_OSC, anchor="e").pack(anchor="e")
        tk.Label(info, text=app.usuario["cargo"].capitalize(), font=F_PEQ, bg=FONDO,
                 fg=VERDE_OSC, anchor="e").pack(anchor="e")
        barra_acento(self).pack(fill="x")

        # ---- cuerpo ----
        cuerpo = tk.Frame(self, bg=FONDO)
        cuerpo.pack(fill="both", expand=True)

        lateral = tk.Frame(cuerpo, bg=GRIS_OSC, width=270)
        lateral.pack(side="left", fill="y")
        lateral.pack_propagate(False)
        tk.Label(lateral, text="MENÚ DE OPERACIONES", font=(F_PEQ[0], 9, "bold"),
                 bg=GRIS_OSC, fg="#A9A9A9").pack(anchor="w", padx=22, pady=(22, 10))

        for clave, texto, roles, _req in self.OPCIONES:
            permitido = roles is None or app.usuario["cargo"] in roles
            etiqueta_btn = texto if permitido else texto + "   🔒"
            b = ttk.Button(lateral, text=etiqueta_btn, style="Side.TButton",
                           command=lambda k=clave: app.mostrar_pagina(k))
            b.pack(fill="x")
            self.botones[clave] = b

        self.contenido = tk.Frame(cuerpo, bg=FONDO)
        self.contenido.pack(side="left", fill="both", expand=True, padx=36, pady=20)

        self.mostrar_bienvenida()

    def _limpiar(self):
        if self.pagina_actual is not None:
            self.pagina_actual.destroy()
            self.pagina_actual = None

    def mostrar_bienvenida(self):
        self._limpiar()
        pag = Pagina(self.contenido, self.app,
                     f"¡Bienvenido(a), {self.app.usuario['nombre']}!",
                     f"Rol: {self.app.usuario['cargo'].capitalize()}")
        tk.Label(pag.cuerpo, text="Selecciona una opción del menú lateral para comenzar.",
                 font=F_BASE, bg=BLANCO, fg=TEXTO).pack(anchor="w")
        pag.pack(fill="both", expand=True)
        self.pagina_actual = pag

    def mostrar(self, clave):
        for k, b in self.botones.items():
            b.configure(style="SideActive.TButton" if k == clave else "Side.TButton")
        self._limpiar()

        cargo = self.app.usuario["cargo"]
        for k, _t, roles, req in self.OPCIONES:
            if k == clave and roles is not None and cargo not in roles:
                pag = PaginaDenegada(self.contenido, self.app, req)
                break
        else:
            pag = self._construir(clave)

        pag.pack(fill="both", expand=True)
        self.pagina_actual = pag

    def _construir(self, clave):
        c, a = self.contenido, self.app
        if clave == "crear":
            return PaginaCrearProyecto(c, a)
        if clave == "actividad":
            return PaginaActividad(c, a)
        if clave == "costo":
            return PaginaCostoEsperado(c, a)
        if clave == "costos":
            return PaginaGraficoCostos(c, a)
        if clave == "tiempos":
            return PaginaGraficoTiempos(c, a)
        if clave == "consumibles":
            return PaginaConsumibles(c, a)
        return PaginaBodega(c, a)


# =====================================================================
# APLICACIÓN
# =====================================================================
class App(tk.Tk):
    def __init__(self):
        super().__init__()
        inicializar_archivos()
        definir_fuentes()
        configurar_estilos(self)

        self.title("Reymon Industrias — Sistema de Gestión de Planta")
        self.configure(bg=FONDO)
        self.minsize(1000, 640)
        centrar(self, 1180, 720)

        self.img_login = cargar_imagen("logo_login.png")
        self.img_header = cargar_imagen("logo_header.png")
        self.img_marca = cargar_imagen("logo_marca.png")   # logo difuminado (marca de agua)
        self.img_fondo_proyecto = cargar_imagen("fondo_proyecto.png")  # fondo de "Crear proyecto"
        self.img_icono = cargar_imagen("logo_icon.png")
        if self.img_icono:
            self.iconphoto(True, self.img_icono)

        self.usuario = None
        self.pantalla = None
        self.mostrar_login()

    @property
    def pagina_actual(self):
        return self.pantalla.pagina_actual if isinstance(self.pantalla, PantallaPrincipal) else None

    def _cambiar(self, pantalla):
        if self.pantalla is not None:
            self.pantalla.destroy()
        self.pantalla = pantalla
        self.pantalla.pack(fill="both", expand=True)

    def mostrar_login(self):
        self.usuario = None
        self._cambiar(PantallaLogin(self, self))

    def mostrar_principal(self, usuario):
        self.usuario = usuario
        self._cambiar(PantallaPrincipal(self, self))

    def mostrar_pagina(self, clave):
        self.pantalla.mostrar(clave)

    def cerrar_sesion(self):
        self.mostrar_login()


def main():
    App().mainloop()


if __name__ == "__main__":
    main()
